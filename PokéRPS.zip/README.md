﻿![](Aspose.Words.e2b14219-a1a4-4ba6-9d45-247e0f55e229.001.png)

# PokéRPS

### Hunter Kalinoski & Cameron Ware

<br>

Hello Dr. Ohl. This is our CV project, PokéRPS (pokémon rock paper scissors).

The game requires a webcam, images of three Pokemon cards.

The three cards should be included in the canvas sumbmission as well as emailed to you for easier transfer, as you will need to display them in front of the camera. Feel free to either print them, or just show them on your phone. Either way will work.

The game uses a live camera feed to detect if there is a card using feature points. All of the CV aspects and how we created the live feature point detector is all in the ImageClassifier.py file.

To launch the game, run main.py. The game will automatically use your default webcam. Please ensure that no other program is using the webcam, as it will not work otherwise.

Requirements file shows all packages needed for the project to run.

There is a how-to/tutorial section in the main menu to explain how to play.

Goodluck!
